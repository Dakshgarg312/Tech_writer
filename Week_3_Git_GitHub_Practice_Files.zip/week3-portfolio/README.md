# Week 3 Git and GitHub Practice Project

This is the starter HTML website used in the professional Week 3 tutorial.

1. Open `index.html` in your browser.
2. To complete the tutorial correctly, create a new folder and follow the steps in the Word guide. Use this ZIP only to compare your results or restore the starter HTML.
3. Later, use the tutorial to create your own local Git commits and GitHub remote repository.

No `.git` folder, credentials, private data, or remote GitHub repository are included.
